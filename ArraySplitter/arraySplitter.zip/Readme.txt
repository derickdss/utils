
Details:
The app has been written in Javascript and can be run using NodeJs.
In order to run the app:
1. You would need NodeJS to create an environment to run javascript. Install node onto your system using `www.nodejs.org`
2. Once installed, navigate to the directory containing the unzipped file in command line.
3. run `node arraySplitter.js`

I've written some test cases that should output on the console.
